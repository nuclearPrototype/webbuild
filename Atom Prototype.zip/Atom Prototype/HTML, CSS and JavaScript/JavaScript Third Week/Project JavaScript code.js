function show_pattern() {
  // Pozicija, dimenzije i boja backgrounda
  var top_position = 25, left_position = 25;
  var width = 500, height = 500;
  var color_list = ["Aqua", "Aquamarine", "Cyan", "DarkCyan", "DarkTurquoise",
                    "Lime", "LimeGreen", "Turquoise", "Teal", "SpringGreen"];
  var the_body = document.getElementById("theBody");

  // Loop - do kada ih treba stvarat
  while (width > 50) {
    // Stvaranje 'div'-a
    var gen_div = document.createElement("div");

    // Odabir boje
    var random_color = Math.random() * 7;
    random_color = Math.floor(random_color);

    // Sklapanje svega u 'div'
    gen_div.style.top = top_position + "px";
    gen_div.style.left = left_position + "px";
    gen_div.style.width = width + "px";
    gen_div.style.height = height + "px";
    gen_div.style.background = color_list[random_color];

    // Dodjela body-ju
    the_body.appendChild(gen_div);

    // Povećanje atributa za sljedeći 'div'
    top_position += 10;
    left_position += 10;
    width -= 20;
    height -= 20;
  }

}
