
    var target;
    var guess_input_tekst;
    var guess_input;
    var finished = false;
    var guesses = 0;

    function do_game(){
      var random = Math.random() * 100;
      var odbaci = Math.floor(random);
      target = odbaci + 1;

      while (!finished) {
        guess_input_tekst = prompt("Guess number between 1 n' 100");
        guess_input = parseInt(guess_input_tekst);
        guesses += 1;
        finished = check_guess();
      }
    }

    function check_guess() {
      if (isNaN(guess_input)) {
        alert("Type a number not nothing else! ;)");
        return false; // Kad je false vrati to i nastavlja sa glavnom while loopom
      }
      if (guess_input < 1 || guess_input > 100) {
        alert("Beteen 1 n' 100 man... ;)");
        return false;
      }
      if (guess_input > target) {
        alert("To large...");
        return false;
      }
      if (guess_input < target) {
        alert("To small...");
        return false;
      }

      alert("Yea man it is " + target + ".\n\n It took you " + guesses + ";)");
      return true;

    }
